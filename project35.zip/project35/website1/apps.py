from django.apps import AppConfig


class Website1Config(AppConfig):
    name = 'website1'
